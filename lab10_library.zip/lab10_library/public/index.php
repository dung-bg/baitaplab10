<?php
// public/index.php - Front Controller
session_start();

$controller = $_GET['c'] ?? 'books';
$action = $_GET['a'] ?? 'index';

// Whitelist controllers
$allowedControllers = ['books', 'borrowers', 'borrows'];
if (!in_array($controller, $allowedControllers)) {
    $controller = 'books';
}

$controllerFile = __DIR__ . "/../app/controllers/" . ucfirst($controller) . "Controller.php";

if (file_exists($controllerFile)) {
    require_once $controllerFile;
    $controllerClass = ucfirst($controller) . 'Controller';
    $controllerObj = new $controllerClass();
    
    if (method_exists($controllerObj, $action)) {
        $controllerObj->$action();
    } else {
        die("Action not found: $action");
    }
} else {
    die("Controller not found: $controller");
}