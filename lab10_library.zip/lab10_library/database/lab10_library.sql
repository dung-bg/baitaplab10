-- Lab 10 - Library Management Database
-- Chủ đề A: Quản lý Thư viện

CREATE DATABASE IF NOT EXISTS lab10_library 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE lab10_library;

-- Bảng Books (Sách)
DROP TABLE IF EXISTS borrow_items;
DROP TABLE IF EXISTS borrows;
DROP TABLE IF EXISTS borrowers;
DROP TABLE IF EXISTS books;

CREATE TABLE books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    author VARCHAR(120) NOT NULL,
    price DECIMAL(10,2) NOT NULL DEFAULT 0,
    qty INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_title (title),
    INDEX idx_author (author)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bảng Borrowers (Người mượn)
CREATE TABLE borrowers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_name (full_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bảng Borrows (Phiếu mượn)
CREATE TABLE borrows (
    id INT AUTO_INCREMENT PRIMARY KEY,
    borrower_id INT NOT NULL,
    borrow_date DATE NOT NULL,
    note VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (borrower_id) REFERENCES borrowers(id) ON DELETE RESTRICT,
    INDEX idx_borrower (borrower_id),
    INDEX idx_date (borrow_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bảng Borrow Items (Chi tiết mượn)
CREATE TABLE borrow_items (
    borrow_id INT NOT NULL,
    book_id INT NOT NULL,
    qty INT NOT NULL,
    PRIMARY KEY (borrow_id, book_id),
    FOREIGN KEY (borrow_id) REFERENCES borrows(id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dữ liệu mẫu Books
INSERT INTO books (title, author, price, qty) VALUES
('Clean Code', 'Robert C. Martin', 450000, 10),
('Design Patterns', 'Gang of Four', 520000, 8),
('The Pragmatic Programmer', 'Andrew Hunt', 380000, 12),
('Refactoring', 'Martin Fowler', 410000, 7),
('Head First Design Patterns', 'Eric Freeman', 360000, 15),
('Code Complete', 'Steve McConnell', 480000, 9),
('The Clean Coder', 'Robert C. Martin', 420000, 11),
('Working Effectively with Legacy Code', 'Michael Feathers', 390000, 6);

-- Dữ liệu mẫu Borrowers
INSERT INTO borrowers (full_name, phone) VALUES
('Nguyen Van An', '0901234567'),
('Tran Thi Binh', '0902345678'),
('Le Van Cuong', '0903456789'),
('Pham Thi Dung', '0904567890'),
('Hoang Van Em', '0905678901');

-- Dữ liệu mẫu Borrows (test)
INSERT INTO borrows (borrower_id, borrow_date, note) VALUES
(1, DATE_SUB(CURDATE(), INTERVAL 5 DAY), 'Mượn sách lập trình'),
(2, DATE_SUB(CURDATE(), INTERVAL 2 DAY), 'Học Design Pattern');

-- Dữ liệu mẫu Borrow Items
INSERT INTO borrow_items (borrow_id, book_id, qty) VALUES
(1, 1, 1),
(1, 2, 1),
(2, 5, 2);

-- Đã trừ qty tương ứng (giả lập)
UPDATE books SET qty = qty - 1 WHERE id IN (1, 2);
UPDATE books SET qty = qty - 2 WHERE id = 5;