========================================
LAB 10 - LIBRARY MANAGEMENT SYSTEM
Chủ đề A: Quản lý Thư viện
========================================

I. THÔNG TIN
-------------
- Database: lab10_library
- User DB: root (development) hoặc lab10_user (production)
- Project: MVC Pattern with Transaction

II. CÀI ĐẶT
------------
1. Import SQL:
   - Mở phpMyAdmin
   - Import file: database/lab10_library.sql

2. Cấu hình (nếu cần):
   - Sửa app/config/db.php
   - Thay đổi DB_USER, DB_PASS

3. Truy cập:
   - URL: http://localhost/lab10_library/public/
   - Hoặc: http://localhost/lab10_library/public/index.php

III. CHỨC NĂNG
--------------
1. Quản lý Sách (Books):
   - Danh sách + tìm kiếm + sắp xếp (WHITELIST)
   - Thêm/Sửa/Xóa (PREPARED STATEMENT)

2. Quản lý Người mượn (Borrowers):
   - Danh sách
   - Thêm/Sửa/Xóa

3. Quản lý Phiếu mượn (Borrows):
   - Tạo phiếu mượn (TRANSACTION)
   - Tự động trừ tồn kho
   - Kiểm tra qty trước khi mượn
   - Rollback nếu không đủ sách

IV. AN TOÀN SQL INJECTION
-------------------------
✓ Tất cả query dùng PREPARED STATEMENT
✓ Tìm kiếm dùng tham số hóa (:search)
✓ Sort/Dir dùng WHITELIST
✓ ID ép kiểu (int) trước khi query
✓ Không hiển thị lỗi SQL ra giao diện
✓ Ghi log lỗi vào error_log

V. TEST CHỐNG SQL INJECTION
----------------------------
1. Tìm kiếm sách với: ' OR 1=1 --
   → Kết quả: Không lỗi, tìm bình thường

2. URL sort: ?sort=id; DROP TABLE books--
   → Kết quả: Bị whitelist chặn, dùng giá trị mặc định

3. Tạo sách với title: "; DELETE FROM books; --
   → Kết quả: Lưu an toàn nhờ prepared statement

VI. CẤU TRÚC THƯMỤC
-------------------
lab10_library/
├── app/
│   ├── config/db.php
│   ├── core/
│   │   ├── Database.php
│   │   └── Controller.php
│   ├── controllers/
│   │   ├── BooksController.php
│   │   ├── BorrowersController.php
│   │   └── BorrowsController.php
│   ├── models/
│   │   ├── BookRepository.php
│   │   ├── BorrowerRepository.php
│   │   └── BorrowRepository.php
│   └── views/
│       ├── layouts/
│       ├── books/
│       ├── borrowers/
│       └── borrows/
├── public/
│   ├── index.php
│   └── assets/
│       └── css/style.css
├── database/
│   └── lab10_library.sql
└── README.txt