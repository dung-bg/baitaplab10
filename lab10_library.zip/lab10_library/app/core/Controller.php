<?php
// app/core/Controller.php
// Base Controller

class Controller {
    
    protected function view($view, $data = []) {
        extract($data);
        
        $viewFile = __DIR__ . "/../views/$view.php";
        
        if (file_exists($viewFile)) {
            require_once $viewFile;
        } else {
            die("View not found: $view");
        }
    }
    
    protected function redirect($url) {
        header("Location: $url");
        exit;
    }
    
    protected function setFlash($key, $message) {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $_SESSION['flash_' . $key] = $message;
    }
    
    protected function getFlash($key) {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        if (isset($_SESSION['flash_' . $key])) {
            $message = $_SESSION['flash_' . $key];
            unset($_SESSION['flash_' . $key]);
            return $message;
        }
        return null;
    }
    
    // Validate integer ID
    protected function validateId($id) {
        $id = (int)$id;
        if ($id <= 0) {
            $this->setFlash('error', 'ID không hợp lệ');
            $this->redirect('index.php');
        }
        return $id;
    }
    
    // Whitelist validation
    protected function validateWhitelist($value, $allowed, $default) {
        return in_array($value, $allowed) ? $value : $default;
    }
}