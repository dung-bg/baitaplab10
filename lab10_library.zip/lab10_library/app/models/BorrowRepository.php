<?php
// app/models/BorrowRepository.php
// TRANSACTION for Borrow Management

require_once __DIR__ . '/../core/Database.php';
require_once __DIR__ . '/BookRepository.php';

class BorrowRepository {
    private $pdo;
    private $bookRepo;
    
    public function __construct() {
        $this->pdo = Database::getInstance()->getConnection();
        $this->bookRepo = new BookRepository();
    }
    
    // Get all borrows with JOIN
    public function all() {
        try {
            $sql = "SELECT b.*, br.full_name as borrower_name 
                    FROM borrows b 
                    JOIN borrowers br ON b.borrower_id = br.id 
                    ORDER BY b.created_at DESC";
            $stmt = $this->pdo->query($sql);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("BorrowRepository::all Error: " . $e->getMessage());
            return [];
        }
    }
    
    // Find borrow with items
    public function find($id) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT b.*, br.full_name as borrower_name, br.phone 
                FROM borrows b 
                JOIN borrowers br ON b.borrower_id = br.id 
                WHERE b.id = ?
            ");
            $stmt->execute([$id]);
            return $stmt->fetch();
        } catch (PDOException $e) {
            error_log("BorrowRepository::find Error: " . $e->getMessage());
            return null;
        }
    }
    
    // Get borrow items
    public function getBorrowItems($borrowId) {
        try {
            $sql = "SELECT bi.*, bk.title, bk.author 
                    FROM borrow_items bi 
                    JOIN books bk ON bi.book_id = bk.id 
                    WHERE bi.borrow_id = ?";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$borrowId]);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("BorrowRepository::getBorrowItems Error: " . $e->getMessage());
            return [];
        }
    }
    
    // Create borrow with TRANSACTION
    public function createBorrow($borrowerId, $borrowDate, $note, $items) {
        try {
            // BEGIN TRANSACTION
            $this->pdo->beginTransaction();
            
            // 1. Kiểm tra tồn kho trước
            foreach ($items as $item) {
                $bookId = (int)$item['book_id'];
                $qty = (int)$item['qty'];
                
                if (!$this->bookRepo->checkStock($bookId, $qty)) {
                    throw new Exception("Sách ID $bookId không đủ tồn kho (cần $qty cuốn)");
                }
            }
            
            // 2. Tạo phiếu mượn
            $sql = "INSERT INTO borrows (borrower_id, borrow_date, note) VALUES (?, ?, ?)";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$borrowerId, $borrowDate, $note]);
            $borrowId = $this->pdo->lastInsertId();
            
            // 3. Thêm chi tiết + trừ tồn kho
            foreach ($items as $item) {
                $bookId = (int)$item['book_id'];
                $qty = (int)$item['qty'];
                
                // Thêm borrow_items
                $sql = "INSERT INTO borrow_items (borrow_id, book_id, qty) VALUES (?, ?, ?)";
                $stmt = $this->pdo->prepare($sql);
                $stmt->execute([$borrowId, $bookId, $qty]);
                
                // Trừ tồn kho
                $this->bookRepo->decreaseStock($bookId, $qty);
            }
            
            // COMMIT
            $this->pdo->commit();
            return ['success' => true, 'borrow_id' => $borrowId];
            
        } catch (Exception $e) {
            // ROLLBACK nếu có lỗi
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            error_log("BorrowRepository::createBorrow Error: " . $e->getMessage());
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    // Delete borrow (không hoàn tồn kho - tùy yêu cầu)
    public function delete($id) {
        try {
            // Cascade delete sẽ tự động xóa borrow_items
            $stmt = $this->pdo->prepare("DELETE FROM borrows WHERE id = ?");
            return $stmt->execute([$id]);
        } catch (PDOException $e) {
            error_log("BorrowRepository::delete Error: " . $e->getMessage());
            return false;
        }
    }
}