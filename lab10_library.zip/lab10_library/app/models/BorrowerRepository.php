<?php
// app/models/BorrowerRepository.php

require_once __DIR__ . '/../core/Database.php';

class BorrowerRepository {
    private $pdo;
    
    public function __construct() {
        $this->pdo = Database::getInstance()->getConnection();
    }
    
    public function all() {
        try {
            $stmt = $this->pdo->query("SELECT * FROM borrowers ORDER BY created_at DESC");
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("BorrowerRepository::all Error: " . $e->getMessage());
            return [];
        }
    }
    
    public function find($id) {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM borrowers WHERE id = ?");
            $stmt->execute([$id]);
            return $stmt->fetch();
        } catch (PDOException $e) {
            error_log("BorrowerRepository::find Error: " . $e->getMessage());
            return null;
        }
    }
    
    public function create($data) {
        try {
            $sql = "INSERT INTO borrowers (full_name, phone) VALUES (?, ?)";
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute([$data['full_name'], $data['phone']]);
        } catch (PDOException $e) {
            error_log("BorrowerRepository::create Error: " . $e->getMessage());
            return false;
        }
    }
    
    public function update($id, $data) {
        try {
            $sql = "UPDATE borrowers SET full_name = ?, phone = ? WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute([$data['full_name'], $data['phone'], $id]);
        } catch (PDOException $e) {
            error_log("BorrowerRepository::update Error: " . $e->getMessage());
            return false;
        }
    }
    
    public function delete($id) {
        try {
            $stmt = $this->pdo->prepare("DELETE FROM borrowers WHERE id = ?");
            return $stmt->execute([$id]);
        } catch (PDOException $e) {
            error_log("BorrowerRepository::delete Error: " . $e->getMessage());
            return false;
        }
    }
}