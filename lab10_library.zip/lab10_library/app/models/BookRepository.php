<?php
// app/models/BookRepository.php
// Book Repository with Prepared Statements

require_once __DIR__ . '/../core/Database.php';

class BookRepository {
    private $pdo;
    
    public function __construct() {
        $this->pdo = Database::getInstance()->getConnection();
    }
    
    // Get all books with search and sort (WHITELIST)
    public function all($search = '', $sort = 'created_at', $dir = 'desc') {
        try {
            // WHITELIST for sort column
            $allowedSort = ['title', 'author', 'price', 'qty', 'created_at'];
            $sort = in_array($sort, $allowedSort) ? $sort : 'created_at';
            
            // WHITELIST for direction
            $allowedDir = ['asc', 'desc'];
            $dir = in_array($dir, $allowedDir) ? $dir : 'desc';
            
            $sql = "SELECT * FROM books WHERE 1=1";
            $params = [];
            
            // PREPARED STATEMENT for search
            if (!empty($search)) {
                $sql .= " AND (title LIKE :search OR author LIKE :search)";
                $params[':search'] = '%' . $search . '%';
            }
            
            // Safe to use $sort/$dir here (đã whitelist)
            $sql .= " ORDER BY $sort $dir";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            
            return $stmt->fetchAll();
            
        } catch (PDOException $e) {
            error_log("BookRepository::all Error: " . $e->getMessage());
            return [];
        }
    }
    
    // Find by ID
    public function find($id) {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM books WHERE id = ?");
            $stmt->execute([$id]);
            return $stmt->fetch();
        } catch (PDOException $e) {
            error_log("BookRepository::find Error: " . $e->getMessage());
            return null;
        }
    }
    
    // Create book
    public function create($data) {
        try {
            $sql = "INSERT INTO books (title, author, price, qty) VALUES (?, ?, ?, ?)";
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute([
                $data['title'],
                $data['author'],
                $data['price'],
                $data['qty']
            ]);
        } catch (PDOException $e) {
            error_log("BookRepository::create Error: " . $e->getMessage());
            return false;
        }
    }
    
    // Update book
    public function update($id, $data) {
        try {
            $sql = "UPDATE books SET title = ?, author = ?, price = ?, qty = ? WHERE id = ?";
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute([
                $data['title'],
                $data['author'],
                $data['price'],
                $data['qty'],
                $id
            ]);
        } catch (PDOException $e) {
            error_log("BookRepository::update Error: " . $e->getMessage());
            return false;
        }
    }
    
    // Delete book
    public function delete($id) {
        try {
            $stmt = $this->pdo->prepare("DELETE FROM books WHERE id = ?");
            return $stmt->execute([$id]);
        } catch (PDOException $e) {
            error_log("BookRepository::delete Error: " . $e->getMessage());
            return false;
        }
    }
    
    // Get books for dropdown (id, title)
    public function getBooksForSelect() {
        try {
            $stmt = $this->pdo->query("SELECT id, title, qty FROM books WHERE qty > 0 ORDER BY title");
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("BookRepository::getBooksForSelect Error: " . $e->getMessage());
            return [];
        }
    }
    
    // Check stock availability
    public function checkStock($bookId, $qtyNeeded) {
        try {
            $stmt = $this->pdo->prepare("SELECT qty FROM books WHERE id = ?");
            $stmt->execute([$bookId]);
            $book = $stmt->fetch();
            
            if (!$book) return false;
            return $book['qty'] >= $qtyNeeded;
            
        } catch (PDOException $e) {
            error_log("BookRepository::checkStock Error: " . $e->getMessage());
            return false;
        }
    }
    
    // Decrease stock (used in transaction)
    public function decreaseStock($bookId, $qty) {
        try {
            $sql = "UPDATE books SET qty = qty - ? WHERE id = ? AND qty >= ?";
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute([$qty, $bookId, $qty]);
        } catch (PDOException $e) {
            error_log("BookRepository::decreaseStock Error: " . $e->getMessage());
            throw $e; // Re-throw for transaction rollback
        }
    }
}