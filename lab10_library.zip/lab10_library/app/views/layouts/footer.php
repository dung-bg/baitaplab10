</div>
<footer class="mt-5 py-3 bg-light text-center">
    <p class="text-muted mb-0">Lab 10 - Library Management &copy; 2024</p>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>