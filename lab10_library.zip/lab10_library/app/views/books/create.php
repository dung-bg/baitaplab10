<?php $title = 'Thêm sách'; include __DIR__ . '/../layouts/header.php'; ?>

<h2>Thêm sách mới</h2>

<?php if ($error): ?>
<div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="POST" action="index.php?c=books&a=store">
    <div class="mb-3">
        <label class="form-label">Tên sách <span class="text-danger">*</span></label>
        <input type="text" name="title" class="form-control" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Tác giả <span class="text-danger">*</span></label>
        <input type="text" name="author" class="form-control" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Giá</label>
        <input type="number" name="price" class="form-control" value="0" min="0">
    </div>
    <div class="mb-3">
        <label class="form-label">Số lượng</label>
        <input type="number" name="qty" class="form-control" value="0" min="0">
    </div>
    <button type="submit" class="btn btn-primary">Lưu</button>
    <a href="index.php?c=books" class="btn btn-secondary">Hủy</a>
</form>

<?php include __DIR__ . '/../layouts/footer.php'; ?>