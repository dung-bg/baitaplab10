<?php $title = 'Danh sách Sách'; include __DIR__ . '/../layouts/header.php'; ?>

<h2>Quản lý Sách</h2>

<?php if ($success): ?>
<div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>
<?php if ($error): ?>
<div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="row mb-3">
    <div class="col-md-6">
        <a href="index.php?c=books&a=create" class="btn btn-primary">+ Thêm sách</a>
    </div>
    <div class="col-md-6">
        <form method="GET" class="d-flex">
            <input type="hidden" name="c" value="books">
            <input type="text" name="search" class="form-control me-2" placeholder="Tìm theo tên/tác giả..." value="<?= htmlspecialchars($search) ?>">
            <button class="btn btn-secondary" type="submit">Tìm</button>
        </form>
    </div>
</div>

<table class="table table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th><a href="?c=books&sort=title&dir=<?= $dir == 'asc' ? 'desc' : 'asc' ?>">Tên sách</a></th>
            <th><a href="?c=books&sort=author&dir=<?= $dir == 'asc' ? 'desc' : 'asc' ?>">Tác giả</a></th>
            <th><a href="?c=books&sort=price&dir=<?= $dir == 'asc' ? 'desc' : 'asc' ?>">Giá</a></th>
            <th><a href="?c=books&sort=qty&dir=<?= $dir == 'asc' ? 'desc' : 'asc' ?>">Tồn kho</a></th>
            <th>Thao tác</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($books as $book): ?>
        <tr>
            <td><?= $book['id'] ?></td>
            <td><?= htmlspecialchars($book['title']) ?></td>
            <td><?= htmlspecialchars($book['author']) ?></td>
            <td><?= number_format($book['price']) ?>đ</td>
            <td><?= $book['qty'] ?></td>
            <td>
                <a href="index.php?c=books&a=edit&id=<?= $book['id'] ?>" class="btn btn-sm btn-warning">Sửa</a>
                <form method="POST" action="index.php?c=books&a=delete" style="display:inline" onsubmit="return confirm('Xác nhận xóa?')">
                    <input type="hidden" name="id" value="<?= $book['id'] ?>">
                    <button class="btn btn-sm btn-danger">Xóa</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php include __DIR__ . '/../layouts/footer.php'; ?>