<?php $title = 'Thêm người mượn'; include __DIR__ . '/../layouts/header.php'; ?>
<h2>Thêm người mượn</h2>
<form method="POST" action="index.php?c=borrowers&a=store">
<div class="mb-3"><label>Họ tên *</label><input type="text" name="full_name" class="form-control" required></div>
<div class="mb-3"><label>Số điện thoại</label><input type="text" name="phone" class="form-control"></div>
<button class="btn btn-primary">Lưu</button> <a href="index.php?c=borrowers" class="btn btn-secondary">Hủy</a>
</form>
<?php include __DIR__ . '/../layouts/footer.php'; ?>