<?php $title = 'Người mượn'; include __DIR__ . '/../layouts/header.php'; ?>
<h2>Quản lý Người mượn</h2>
<?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<a href="index.php?c=borrowers&a=create" class="btn btn-primary mb-3">+ Thêm người mượn</a>
<table class="table table-striped"><thead><tr><th>ID</th><th>Họ tên</th><th>SĐT</th><th>Thao tác</th></tr></thead><tbody>
<?php foreach ($borrowers as $b): ?>
<tr><td><?= $b['id'] ?></td><td><?= htmlspecialchars($b['full_name']) ?></td><td><?= htmlspecialchars($b['phone'] ?? '') ?></td>
<td><a href="index.php?c=borrowers&a=edit&id=<?= $b['id'] ?>" class="btn btn-sm btn-warning">Sửa</a>
<form method="POST" action="index.php?c=borrowers&a=delete" style="display:inline" onsubmit="return confirm('Xóa?')">
<input type="hidden" name="id" value="<?= $b['id'] ?>"><button class="btn btn-sm btn-danger">Xóa</button></form></td></tr>
<?php endforeach; ?>
</tbody></table>
<?php include __DIR__ . '/../layouts/footer.php'; ?>