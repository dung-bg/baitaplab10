<?php $title = 'Sửa người mượn'; include __DIR__ . '/../layouts/header.php'; ?>
<h2>Sửa người mượn</h2>
<form method="POST" action="index.php?c=borrowers&a=update">
<input type="hidden" name="id" value="<?= $borrower['id'] ?>">
<div class="mb-3"><label>Họ tên</label><input type="text" name="full_name" class="form-control" value="<?= htmlspecialchars($borrower['full_name']) ?>" required></div>
<div class="mb-3"><label>SĐT</label><input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($borrower['phone'] ?? '') ?>"></div>
<button class="btn btn-primary">Cập nhật</button> <a href="index.php?c=borrowers" class="btn btn-secondary">Hủy</a>
</form>
<?php include __DIR__ . '/../layouts/footer.php'; ?>