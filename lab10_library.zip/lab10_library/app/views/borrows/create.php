<?php $title = 'Tạo phiếu mượn'; include __DIR__ . '/../layouts/header.php'; ?>
<h2>Tạo phiếu mượn sách</h2>
<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<form method="POST" action="index.php?c=borrows&a=store">
<div class="mb-3"><label>Người mượn *</label><select name="borrower_id" class="form-control" required>
<option value="">-- Chọn --</option>
<?php foreach ($borrowers as $b): ?><option value="<?= $b['id'] ?>"><?= htmlspecialchars($b['full_name']) ?></option><?php endforeach; ?>
</select></div>
<div class="mb-3"><label>Ngày mượn</label><input type="date" name="borrow_date" class="form-control" value="<?= date('Y-m-d') ?>"></div>
<div class="mb-3"><label>Ghi chú</label><input type="text" name="note" class="form-control"></div>
<h4>Chọn sách mượn</h4>
<div id="books-container">
<div class="row mb-2"><div class="col-md-8"><select name="book_id[]" class="form-control" required>
<option value="">-- Chọn sách --</option>
<?php foreach ($books as $bk): ?><option value="<?= $bk['id'] ?>"><?= htmlspecialchars($bk['title']) ?> (Còn: <?= $bk['qty'] ?>)</option><?php endforeach; ?>
</select></div><div class="col-md-4"><input type="number" name="qty[]" class="form-control" placeholder="SL" min="1" value="1"></div></div>
</div>
<button type="button" class="btn btn-sm btn-secondary mb-3" onclick="addBook()">+ Thêm sách</button><br>
<button class="btn btn-primary">Tạo phiếu</button> <a href="index.php?c=borrows" class="btn btn-secondary">Hủy</a>
</form>
<script>
function addBook(){
let html = '<div class="row mb-2"><div class="col-md-8"><select name="book_id[]" class="form-control">'+
'<option value="">-- Chọn sách --</option><?php foreach ($books as $bk): ?><option value="<?= $bk["id"] ?>"><?= htmlspecialchars($bk["title"]) ?> (Còn: <?= $bk["qty"] ?>)</option><?php endforeach; ?></select></div>'+
'<div class="col-md-4"><input type="number" name="qty[]" class="form-control" placeholder="SL" min="1" value="1"></div></div>';
document.getElementById('books-container').insertAdjacentHTML('beforeend', html);
}
</script>
<?php include __DIR__ . '/../layouts/footer.php'; ?>