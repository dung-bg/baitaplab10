<?php $title = 'Phiếu mượn'; include __DIR__ . '/../layouts/header.php'; ?>
<h2>Danh sách Phiếu mượn</h2>
<?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<a href="index.php?c=borrows&a=create" class="btn btn-primary mb-3">+ Tạo phiếu mượn</a>
<table class="table"><thead><tr><th>ID</th><th>Người mượn</th><th>Ngày mượn</th><th>Ghi chú</th><th>Thao tác</th></tr></thead><tbody>
<?php foreach ($borrows as $b): ?>
<tr><td><?= $b['id'] ?></td><td><?= htmlspecialchars($b['borrower_name']) ?></td><td><?= $b['borrow_date'] ?></td><td><?= htmlspecialchars($b['note'] ?? '') ?></td>
<td><a href="index.php?c=borrows&a=show&id=<?= $b['id'] ?>" class="btn btn-sm btn-info">Xem</a>
<form method="POST" action="index.php?c=borrows&a=delete" style="display:inline" onsubmit="return confirm('Xóa?')">
<input type="hidden" name="id" value="<?= $b['id'] ?>"><button class="btn btn-sm btn-danger">Xóa</button></form></td></tr>
<?php endforeach; ?>
</tbody></table>
<?php include __DIR__ . '/../layouts/footer.php'; ?>