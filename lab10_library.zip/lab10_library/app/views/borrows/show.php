<?php $title = 'Chi tiết phiếu mượn'; include __DIR__ . '/../layouts/header.php'; ?>
<h2>Chi tiết phiếu mượn #<?= $borrow['id'] ?></h2>
<div class="card mb-3"><div class="card-body">
<p><strong>Người mượn:</strong> <?= htmlspecialchars($borrow['borrower_name']) ?></p>
<p><strong>SĐT:</strong> <?= htmlspecialchars($borrow['phone'] ?? '') ?></p>
<p><strong>Ngày mượn:</strong> <?= $borrow['borrow_date'] ?></p>
<p><strong>Ghi chú:</strong> <?= htmlspecialchars($borrow['note'] ?? '') ?></p>
</div></div>
<h4>Danh sách sách mượn</h4>
<table class="table"><thead><tr><th>Sách</th><th>Tác giả</th><th>Số lượng</th></tr></thead><tbody>
<?php foreach ($items as $item): ?>
<tr><td><?= htmlspecialchars($item['title']) ?></td><td><?= htmlspecialchars($item['author']) ?></td><td><?= $item['qty'] ?></td></tr>
<?php endforeach; ?>
</tbody></table>
<a href="index.php?c=borrows" class="btn btn-secondary">Quay lại</a>
<?php include __DIR__ . '/../layouts/footer.php'; ?>