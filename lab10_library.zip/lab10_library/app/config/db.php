<?php
// app/config/db.php
// Cấu hình database - Lab 10

// === PRODUCTION CONFIG (User riêng - Khuyến nghị) ===
// Tạo user riêng trong MySQL:
// CREATE USER 'lab10_user'@'localhost' IDENTIFIED BY 'lab10_pass';
// GRANT SELECT, INSERT, UPDATE, DELETE ON lab10_library.* TO 'lab10_user'@'localhost';
// FLUSH PRIVILEGES;

define('DB_HOST', 'localhost');
define('DB_NAME', 'lab10_library');

// DEVELOPMENT: Dùng root (CHỈ cho học tập)
define('DB_USER', 'root');
define('DB_PASS', '');

// PRODUCTION: Nên dùng user riêng
// define('DB_USER', 'lab10_user');
// define('DB_PASS', 'lab10_pass');

define('DB_CHARSET', 'utf8mb4');

date_default_timezone_set('Asia/Ho_Chi_Minh');