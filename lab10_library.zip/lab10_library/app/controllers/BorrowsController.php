<?php
// app/controllers/BorrowsController.php

require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../models/BorrowRepository.php';
require_once __DIR__ . '/../models/BorrowerRepository.php';
require_once __DIR__ . '/../models/BookRepository.php';

class BorrowsController extends Controller {
    private $repo;
    private $borrowerRepo;
    private $bookRepo;
    
    public function __construct() {
        $this->repo = new BorrowRepository();
        $this->borrowerRepo = new BorrowerRepository();
        $this->bookRepo = new BookRepository();
    }
    
    public function index() {
        $borrows = $this->repo->all();
        $this->view('borrows/index', [
            'borrows' => $borrows,
            'success' => $this->getFlash('success'),
            'error' => $this->getFlash('error')
        ]);
    }
    
    public function create() {
        $borrowers = $this->borrowerRepo->all();
        $books = $this->bookRepo->getBooksForSelect();
        
        $this->view('borrows/create', [
            'borrowers' => $borrowers,
            'books' => $books,
            'error' => $this->getFlash('error')
        ]);
    }
    
    public function store() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('index.php?c=borrows');
        }
        
        $borrowerId = $this->validateId($_POST['borrower_id'] ?? 0);
        $borrowDate = $_POST['borrow_date'] ?? date('Y-m-d');
        $note = trim($_POST['note'] ?? '');
        
        // Validate items
        $bookIds = $_POST['book_id'] ?? [];
        $qtys = $_POST['qty'] ?? [];
        
        if (empty($bookIds)) {
            $this->setFlash('error', 'Vui lòng chọn ít nhất 1 sách');
            $this->redirect('index.php?c=borrows&a=create');
        }
        
        $items = [];
        foreach ($bookIds as $index => $bookId) {
            $qty = (int)($qtys[$index] ?? 0);
            if ($qty > 0) {
                $items[] = ['book_id' => (int)$bookId, 'qty' => $qty];
            }
        }
        
        if (empty($items)) {
            $this->setFlash('error', 'Số lượng phải > 0');
            $this->redirect('index.php?c=borrows&a=create');
        }
        
        // Create borrow with TRANSACTION
        $result = $this->repo->createBorrow($borrowerId, $borrowDate, $note, $items);
        
        if ($result['success']) {
            $this->setFlash('success', 'Tạo phiếu mượn thành công!');
            $this->redirect('index.php?c=borrows&a=show&id=' . $result['borrow_id']);
        } else {
            $this->setFlash('error', 'Lỗi: ' . $result['message']);
            $this->redirect('index.php?c=borrows&a=create');
        }
    }
    
    public function show() {
        $id = $this->validateId($_GET['id'] ?? 0);
        $borrow = $this->repo->find($id);
        
        if (!$borrow) {
            $this->setFlash('error', 'Không tìm thấy phiếu mượn');
            $this->redirect('index.php?c=borrows');
        }
        
        $items = $this->repo->getBorrowItems($id);
        
        $this->view('borrows/show', [
            'borrow' => $borrow,
            'items' => $items
        ]);
    }
    
    public function delete() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('index.php?c=borrows');
        }
        
        $id = $this->validateId($_POST['id'] ?? 0);
        
        if ($this->repo->delete($id)) {
            $this->setFlash('success', 'Xóa phiếu mượn thành công');
        } else {
            $this->setFlash('error', 'Lỗi khi xóa');
        }
        
        $this->redirect('index.php?c=borrows');
    }
}