<?php
// app/controllers/BorrowersController.php

require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../models/BorrowerRepository.php';

class BorrowersController extends Controller {
    private $repo;
    
    public function __construct() {
        $this->repo = new BorrowerRepository();
    }
    
    public function index() {
        $borrowers = $this->repo->all();
        $this->view('borrowers/index', [
            'borrowers' => $borrowers,
            'success' => $this->getFlash('success'),
            'error' => $this->getFlash('error')
        ]);
    }
    
    public function create() {
        $this->view('borrowers/create');
    }
    
    public function store() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('index.php?c=borrowers');
        }
        
        $fullName = trim($_POST['full_name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        
        if (empty($fullName)) {
            $this->setFlash('error', 'Họ tên không được trống');
            $this->redirect('index.php?c=borrowers&a=create');
        }
        
        if ($this->repo->create(['full_name' => $fullName, 'phone' => $phone])) {
            $this->setFlash('success', 'Thêm người mượn thành công');
        } else {
            $this->setFlash('error', 'Lỗi khi thêm');
        }
        
        $this->redirect('index.php?c=borrowers');
    }
    
    public function edit() {
        $id = $this->validateId($_GET['id'] ?? 0);
        $borrower = $this->repo->find($id);
        
        if (!$borrower) {
            $this->setFlash('error', 'Không tìm thấy');
            $this->redirect('index.php?c=borrowers');
        }
        
        $this->view('borrowers/edit', ['borrower' => $borrower]);
    }
    
    public function update() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('index.php?c=borrowers');
        }
        
        $id = $this->validateId($_POST['id'] ?? 0);
        $fullName = trim($_POST['full_name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        
        if (empty($fullName)) {
            $this->setFlash('error', 'Họ tên không được trống');
            $this->redirect("index.php?c=borrowers&a=edit&id=$id");
        }
        
        if ($this->repo->update($id, ['full_name' => $fullName, 'phone' => $phone])) {
            $this->setFlash('success', 'Cập nhật thành công');
        } else {
            $this->setFlash('error', 'Lỗi khi cập nhật');
        }
        
        $this->redirect('index.php?c=borrowers');
    }
    
    public function delete() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('index.php?c=borrowers');
        }
        
        $id = $this->validateId($_POST['id'] ?? 0);
        
        if ($this->repo->delete($id)) {
            $this->setFlash('success', 'Xóa thành công');
        } else {
            $this->setFlash('error', 'Không thể xóa (có phiếu mượn liên quan)');
        }
        
        $this->redirect('index.php?c=borrowers');
    }
}