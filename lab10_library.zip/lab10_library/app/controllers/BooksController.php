<?php
// app/controllers/BooksController.php

require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../models/BookRepository.php';

class BooksController extends Controller {
    private $repo;
    
    public function __construct() {
        $this->repo = new BookRepository();
    }
    
    // List books
    public function index() {
        $search = $_GET['search'] ?? '';
        $sort = $_GET['sort'] ?? 'created_at';
        $dir = $_GET['dir'] ?? 'desc';
        
        $books = $this->repo->all($search, $sort, $dir);
        
        $this->view('books/index', [
            'books' => $books,
            'search' => $search,
            'sort' => $sort,
            'dir' => $dir,
            'success' => $this->getFlash('success'),
            'error' => $this->getFlash('error')
        ]);
    }
    
    // Show create form
    public function create() {
        $this->view('books/create', [
            'error' => $this->getFlash('error')
        ]);
    }
    
    // Store new book
    public function store() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('index.php?c=books&a=index');
        }
        
        // Validate
        $errors = [];
        $title = trim($_POST['title'] ?? '');
        $author = trim($_POST['author'] ?? '');
        $price = $_POST['price'] ?? 0;
        $qty = $_POST['qty'] ?? 0;
        
        if (empty($title)) $errors[] = "Tên sách không được trống";
        if (empty($author)) $errors[] = "Tác giả không được trống";
        if (!is_numeric($price) || $price < 0) $errors[] = "Giá phải >= 0";
        if (!is_numeric($qty) || $qty < 0) $errors[] = "Số lượng phải >= 0";
        
        if (!empty($errors)) {
            $this->setFlash('error', implode(', ', $errors));
            $this->redirect('index.php?c=books&a=create');
        }
        
        $data = [
            'title' => $title,
            'author' => $author,
            'price' => $price,
            'qty' => $qty
        ];
        
        if ($this->repo->create($data)) {
            $this->setFlash('success', 'Thêm sách thành công');
        } else {
            $this->setFlash('error', 'Lỗi khi thêm sách');
        }
        
        $this->redirect('index.php?c=books&a=index');
    }
    
    // Show edit form
    public function edit() {
        $id = $this->validateId($_GET['id'] ?? 0);
        $book = $this->repo->find($id);
        
        if (!$book) {
            $this->setFlash('error', 'Không tìm thấy sách');
            $this->redirect('index.php?c=books&a=index');
        }
        
        $this->view('books/edit', [
            'book' => $book,
            'error' => $this->getFlash('error')
        ]);
    }
    
    // Update book
    public function update() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('index.php?c=books&a=index');
        }
        
        $id = $this->validateId($_POST['id'] ?? 0);
        
        $errors = [];
        $title = trim($_POST['title'] ?? '');
        $author = trim($_POST['author'] ?? '');
        $price = $_POST['price'] ?? 0;
        $qty = $_POST['qty'] ?? 0;
        
        if (empty($title)) $errors[] = "Tên sách không được trống";
        if (empty($author)) $errors[] = "Tác giả không được trống";
        if (!is_numeric($price) || $price < 0) $errors[] = "Giá phải >= 0";
        if (!is_numeric($qty) || $qty < 0) $errors[] = "Số lượng phải >= 0";
        
        if (!empty($errors)) {
            $this->setFlash('error', implode(', ', $errors));
            $this->redirect("index.php?c=books&a=edit&id=$id");
        }
        
        $data = [
            'title' => $title,
            'author' => $author,
            'price' => $price,
            'qty' => $qty
        ];
        
        if ($this->repo->update($id, $data)) {
            $this->setFlash('success', 'Cập nhật thành công');
        } else {
            $this->setFlash('error', 'Lỗi khi cập nhật');
        }
        
        $this->redirect('index.php?c=books&a=index');
    }
    
    // Delete book
    public function delete() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('index.php?c=books&a=index');
        }
        
        $id = $this->validateId($_POST['id'] ?? 0);
        
        if ($this->repo->delete($id)) {
            $this->setFlash('success', 'Xóa sách thành công');
        } else {
            $this->setFlash('error', 'Lỗi khi xóa sách (có thể đang được mượn)');
        }
        
        $this->redirect('index.php?c=books&a=index');
    }
}